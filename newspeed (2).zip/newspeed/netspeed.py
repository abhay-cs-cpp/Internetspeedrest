from tkinter import *
from speedtest import Speedtest


root = Tk()
root.title("Internet Speed Checker")
root.geometry('800x800')
root.resizable(True,True)


bg_image = PhotoImage(file='image.png')
bg = Label(image=bg_image).grid(row=5,column=5,padx=100,pady=55)


def get_speed():
    s = Speedtest()
    download = s.download()
    upload = s.upload()
    download_speed = round(download/(10**6),2)
    upload_speed = round(upload/(10**6),2)
    down_lab.config(text='Download Speed is: ' + str(download_speed) + "Mbps")
    upload_lab.config(text='Upload Speed is: ' + str(upload_speed) + "Mbps")


fg = '#0cc6a9'
bg = '#ed4947'


Button(root,text='Get Speed',font=('Arial',14,'bold'),command=get_speed,bg=bg).grid(row=5,column=5,padx=5,pady=10)


down_lab = Label(root,text='',fg=fg,font=('Helvetica',14,'bold'))
down_lab.grid(row=2,column=0,pady=15,padx=15)


upload_lab = Label(root,text='',fg=fg,font=('Helvetica',14,'bold'))
upload_lab.grid(row=3,column=0,pady=5,padx=5)


root.mainloop() 

